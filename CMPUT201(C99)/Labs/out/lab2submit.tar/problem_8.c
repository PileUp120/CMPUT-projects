#include <stdio.h>

int main(){
  float loan;
  float rate;
  float payment;
  printf("Enter loan amount: ");
  scanf("%f", &loan);
  printf("Enter interest rate: ");
  scanf("%f", &rate);
  printf("Enter monthly payment: ");
  scanf("%f", &payment);
  float mrate = (rate/100)/12;
  float balance = loan + (loan*mrate)-payment;
  printf("Balance remaining after first payment: $%.2f\n", balance);
  balance = balance + (balance*mrate)-payment;
  printf("Balance remaining after second payment: $%.2f\n", balance);
  balance =balance + (balance*mrate)-payment;
  printf("Balance remaining after third payment: $%.2f\n", balance);
  return 0;
}
