#include <stdio.h>
#define MaxLen 80

void encrypt(char *message, int shift);

int main(){

char c, message[MaxLen];
int i, shift;

printf("Enter message to be encrypted: ");
for(i = 0; (c = getchar()) != '\n' && i < MaxLen; i++)
message[i] = c;

printf("Enter shift amount: ");
scanf("%d", &shift);
printf("Encrypted message: ");
encrypt(message, shift);
printf("\n");
return 0;}

void encrypt(char *message, int shift){

char *l;

for (l = message; *l; l++){
if (*l >='A' && *l <= 'Z')
printf("%c", ((*l - 'A') + shift)%26 + 'A');
else if (*l >= 'a' && *l <= 'z')
printf("%c", ((*l - 'a') + shift)%26 + 'a');
else
printf("%c", *l);}} 
