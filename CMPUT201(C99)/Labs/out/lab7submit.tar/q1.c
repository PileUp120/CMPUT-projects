#include <stdio.h>
#define MaxLen 100

int main(){
char message[MaxLen];
char c, *p;
printf("Enter a message: ");

for(p = &message[0]; p<&message[0] + MaxLen; p++){
if((c = getchar()) == '\n') break;
*p = c;}

printf("Reversal is: ");

for(p = p-1; p>= &message[0]; p--)
putchar(*p);
printf("\n");
return 0;}
