#include <stdio.h>
#define MaxLen 100

int main(){
char message[MaxLen];
char c, *p = message;

printf("Enter a message: ");

while((c = getchar()) != '\n' && p < message + MaxLen)
*p++ = c;

printf("Reversal is: ");

while(p >=message)
putchar(*p--);

printf("\n");
return 0;}
