#include <stdio.h>

int main(){
int num, denom, i1, i2, r;
printf("Enter a fraction: ");
scanf("%d/%d", &num, &denom);
i1 = num;
i2 = denom;
while (i2 != 0){
r = i1 % i2;
i1 = i2;
i2 = r;}
printf("In lowest terms: %d/%d\n", num/i1, denom/i1);
return 0;}
