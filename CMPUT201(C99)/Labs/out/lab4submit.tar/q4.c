#include <stdio.h>
#include <stdlib.h>

int main(){
int num, bin, bit;
float dec;
printf("Enter a positive integer: ");
scanf("%d", &num);
printf("The machine format is: ");
for (bit = 32 -1;bit >= 0;bit--){
bin = num >> bit;
if (bin & 1)
printf("1");
else
printf("0");}
printf("\nEnter a positive floating point number: ");
scanf("%f", &dec);
printf("The machine format is: ");
if (dec > 0)
printf("0");
else
printf("1");
for (bit = 8 -1;bit >= 0;bit--){
bin = (int)dec >> bit;
if(bin & 1)
printf("1");
else
printf("0");}
float dadp = abs(dec - (int)dec);
for (bit = 23 -1; bit >=0;bit--){
if (dadp*2 >1){
printf("1");
dadp -= 1;}
else
printf("0");
}
printf("\n");
return 0;}
