#include <stdio.h>

int main(){
int i1, i2, r;
printf("Enter two integers: ");
scanf("%d%d", &i1, &i2);
while(i2 != 0){
r = i1 % i2;
i1 = i2;
i2 = r;}
printf("Greatest common divisor: %d\n", i1);
return 0;}
