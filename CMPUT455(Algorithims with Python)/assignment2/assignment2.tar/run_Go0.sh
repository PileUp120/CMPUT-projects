python3 Go0.py
